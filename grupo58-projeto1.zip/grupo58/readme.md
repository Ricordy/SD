Trabalho realizado por: 

Rodrigo Barrocas - 50%
Matheus Nunes - 50%
Pedro Vaz - 0 %

Não conseguimos terminar o table pois tinhamos/temos alguns erros no delete da table. 
Com os erros mencionados e o tempo gasto a tentar entender a situação, não restou tempo para o serialization.