Trabalho realizado por: 

Rodrigo Barrocas - 49%
Matheus Nunes - 49%
Pedro Vaz - 2 %

Todos os requisitos do makefile estão cumpridos. 
O cliente conecta-se ao servidor e desconecta-se 
O servidor aceita conexões edesconexões.

Erros: 
- Tanto o cliente como o servidor ficam pendurados à quando tentam ler a informação. Gastamos imenso tempo a tentar entender o porque desta situação, mas não conseguimos, visto que as operações de write parecem funcionar.